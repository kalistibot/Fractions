#ifndef _FRACTIONMATH_
#define _FRACTIONMATH_

int GCD(int a, int b);
int LCM(int a,int b);

#endif
